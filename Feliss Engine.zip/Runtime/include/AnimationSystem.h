// AnimationSystem.h placeholder
