// MaterialComponent.h placeholder
