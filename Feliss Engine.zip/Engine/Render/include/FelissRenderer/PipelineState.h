// PipelineState.h placeholder
