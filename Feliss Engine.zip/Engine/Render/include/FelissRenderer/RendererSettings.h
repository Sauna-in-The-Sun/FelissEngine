// RendererSettings.h placeholder
