// EditorMenuBar.h placeholder
