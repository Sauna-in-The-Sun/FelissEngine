// SceneHierarchyPanel.h placeholder
