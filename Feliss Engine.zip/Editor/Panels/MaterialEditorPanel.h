// MaterialEditorPanel.h placeholder
